importScripts('config.js');

const ML_COOKIE_NAMES = ['_csrf', 'ssid', 'orguseridp', 'orgnickp'];
const ML_COOKIE_URL   = 'https://www.mercadolivre.com.br/';

async function extractMeliSession() {
  const results = {};
  for (const name of ML_COOKIE_NAMES) {
    const cookie = await chrome.cookies.get({ url: ML_COOKIE_URL, name });
    if (cookie && cookie.value) results[name] = cookie.value;
  }

  // Todos os 3 cookies são obrigatórios
  if (!results['ssid'] || !results['_csrf'] || !results['orguseridp']) {
    return null; // sessão incompleta — não sincronizar
  }

  const cookieParts = ML_COOKIE_NAMES
    .filter(n => results[n])
    .map(n => `${n}=${results[n]}`);

  return {
    csrf_token:    results['_csrf'],
    cookie_string: cookieParts.join('; '),
    meli_user_id:  results['orguseridp'],
    orgnickp:      results['orgnickp']
  };
  // NUNCA logar valores acima
}

async function performSync() {
  const stored = await chrome.storage.local.get(['extension_token', 'consent_given']);

  if (!stored.extension_token) {
    console.info('[SYNCO] Sync cancelado: não pareado');
    return { success: false, status: 'not_paired' };
  }

  if (!stored.consent_given) {
    console.info('[SYNCO] Sync cancelado: consentimento não dado');
    return { success: false, status: 'no_consent' };
  }

  const sessionData = await extractMeliSession();
  if (!sessionData) {
    console.warn('[SYNCO] Sync cancelado: sessão ML incompleta ou usuário não logado');
    return { success: false, status: 'ml_not_logged_in' };
  }

  try {
    const response = await fetch(
      SYNCO_CONFIG.API_BASE_URL + SYNCO_CONFIG.ENDPOINTS.SESSION_SYNC,
      {
        method: 'PUT',
        headers: {
          'Authorization': 'Bearer ' + stored.extension_token,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ session_snapshot: sessionData })
      }
    );

    if (response.status === 401) {
      console.warn('[SYNCO] Token inválido — removendo pareamento');
      await chrome.storage.local.remove(['extension_token', 'consent_given']);
      return { success: false, status: 'invalid_token' };
    }

    if (response.ok) {
      await chrome.storage.local.set({ last_sync_at: new Date().toISOString() });
      console.info('[SYNCO] Sessão sincronizada');
      return { success: true, status: 'synced' };
    }

    console.warn('[SYNCO] Sincronização falhou: status', response.status);
    return { success: false, status: 'sync_failed' };

  } catch (err) {
    console.warn('[SYNCO] Erro de rede na sincronização');
    return { success: false, status: 'sync_failed' };
  }
  // NUNCA logar sessionData, extension_token ou detalhes do erro
}

async function disconnectSession() {
  const { extension_token } = await chrome.storage.local.get(['extension_token']);
  if (extension_token) {
    try {
      await fetch(
        SYNCO_CONFIG.API_BASE_URL + SYNCO_CONFIG.ENDPOINTS.SESSION_REVOKE,
        {
          method: 'DELETE',
          headers: { 'Authorization': 'Bearer ' + extension_token }
        }
      );
    } catch (_) {
      // Revogar localmente mesmo se a chamada falhar
    }
  }
  await chrome.storage.local.remove(['extension_token', 'last_sync_at', 'consent_given']);
  console.info('[SYNCO] Sessão desconectada');
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('mlSync', { periodInMinutes: 30 });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'mlSync') performSync();
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'forceSync') {
    performSync().then(result => sendResponse(result));
    return true;
  }
  if (request.action === 'disconnect') {
    disconnectSession().then(() => sendResponse({ success: true }));
    return true;
  }
});
