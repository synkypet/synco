const SYNCO_CONFIG = {
  API_BASE_URL: 'https://synco-six.vercel.app',
  ENDPOINTS: {
    PAIRING_EXCHANGE: '/api/ml/pairing/exchange',
    SESSION_SYNC:     '/api/ml/session/sync',
    SESSION_REVOKE:   '/api/ml/session/revoke'
  }
};
