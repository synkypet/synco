# Synco — Extensão Mercado Livre (MVP via ZIP)

> Esta é uma versão MVP de instalação manual. No futuro, a extensão
> poderá estar disponível na Chrome Web Store.

## Pré-requisitos
- Google Chrome versão 116 ou superior
- Conta ativa no Synco

## Instalação
1. Descompacte o arquivo synco-ml-extension.zip em qualquer pasta
2. Abra o Chrome e acesse chrome://extensions
3. Ative o "Modo do desenvolvedor" (toggle superior direito)
4. Clique em "Carregar sem compactação"
5. Selecione a pasta descompactada (synco-ml-extension/)
6. O ícone Synco aparecerá na barra do Chrome

## Pareamento
1. Acesse o painel Synco → Configurações → Mercado Livre
2. Clique em "Parear extensão" para gerar o código de 6 dígitos
   (o código expira em 10 minutos)
3. Clique no ícone Synco no Chrome
4. Cole o código e marque a autorização
5. Clique em "Conectar ao Synco"
6. Certifique-se de estar logado no Mercado Livre no Chrome
7. Clique em "Sincronizar agora"

## Desconexão
- Clique no ícone Synco → "Desconectar"
- Isso revoga a sessão no servidor e remove os dados locais

## Atualização
1. Baixe o novo ZIP pelo painel Synco
2. Descompacte substituindo a pasta anterior
3. Em chrome://extensions, clique no ícone de atualização (↺) da extensão

## Privacidade
- A extensão acessa apenas os cookies de sessão do Mercado Livre
- Nenhum dado é armazenado localmente além do token de pareamento
- A sessão expira automaticamente em 7 dias
- Você pode revogar o acesso a qualquer momento clicando em "Desconectar"
