document.addEventListener('DOMContentLoaded', () => {
  const views = {
    pairing: document.getElementById('view-pairing'),
    connected: document.getElementById('view-connected'),
    loading: document.getElementById('view-loading'),
    error: document.getElementById('view-error')
  };

  const btnPair = document.getElementById('btn-pair');
  const btnSyncNow = document.getElementById('btn-sync-now');
  const btnDisconnect = document.getElementById('btn-disconnect');
  const btnErrorRetry = document.getElementById('btn-error-retry');
  const consentCheckbox = document.getElementById('consent-checkbox');
  const pairingCodeInput = document.getElementById('pairing-code-input');
  const pairingError = document.getElementById('pairing-error');
  const syncFeedback = document.getElementById('sync-feedback');
  const syncStatusText = document.getElementById('sync-status-text');

  function showView(name) {
    Object.values(views).forEach(v => v.classList.add('hidden'));
    views[name].classList.remove('hidden');
  }

  function updateSyncStatus(last_sync_at) {
    if (!last_sync_at) {
      syncStatusText.textContent = "Última sync: nunca";
    } else {
      const d = new Date(last_sync_at);
      syncStatusText.textContent = "Última sync: " + d.toLocaleString('pt-BR');
    }
  }

  function showError(msg) {
    pairingError.textContent = msg;
    pairingError.classList.remove('hidden');
  }

  function hideError() {
    pairingError.classList.add('hidden');
  }

  function showFeedback(msg) {
    syncFeedback.textContent = msg;
    syncFeedback.classList.remove('hidden');
  }

  function hideFeedback() {
    syncFeedback.classList.add('hidden');
  }

  function init() {
    chrome.storage.local.get(['extension_token', 'last_sync_at'], data => {
      if (data.extension_token) {
        showView('connected');
        updateSyncStatus(data.last_sync_at);
      } else {
        showView('pairing');
      }
    });
  }

  consentCheckbox.addEventListener('change', () => {
    btnPair.disabled = !consentCheckbox.checked;
  });

  btnPair.addEventListener('click', async () => {
    hideError();
    const code = pairingCodeInput.value.trim();
    if (!/^\d{6}$/.test(code)) {
      showError("Código inválido. Digite 6 dígitos.");
      return;
    }
    if (!consentCheckbox.checked) {
      showError("Aceite os termos para continuar.");
      return;
    }

    showView('loading');

    try {
      const response = await fetch(SYNCO_CONFIG.API_BASE_URL + SYNCO_CONFIG.ENDPOINTS.PAIRING_EXCHANGE, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pairing_code: code })
      });

      if (response.ok) {
        const data = await response.json();
        await chrome.storage.local.set({
          extension_token: data.extension_token,
          consent_given: true
        });
        showView('connected');
        
        chrome.runtime.sendMessage({ action: 'forceSync' }, result => {
          updateSyncStatus(result && result.status === 'synced' ? new Date().toISOString() : null);
        });
      } else if (response.status === 401) {
        showError("Código inválido ou expirado.");
        showView('pairing');
      } else {
        showError("Não foi possível conectar. Tente novamente.");
        showView('pairing');
      }
    } catch (err) {
      showError("Não foi possível conectar. Tente novamente.");
      showView('pairing');
    }
  });

  btnSyncNow.addEventListener('click', () => {
    btnSyncNow.disabled = true;
    showFeedback("Sincronizando...");
    
    chrome.runtime.sendMessage({ action: 'forceSync' }, result => {
      btnSyncNow.disabled = false;
      
      const messages = {
        synced:           'Sincronizado com sucesso!',
        ml_not_logged_in: 'Faça login no Mercado Livre e tente novamente.',
        invalid_token:    'Sessão expirada. Reconecte a extensão.',
        sync_failed:      'Falha na sincronização. Tente novamente.',
        no_consent:       'Consentimento necessário.'
      };
      
      const msg = messages[result.status] || 'Resposta inesperada.';
      showFeedback(msg);
      
      if (result.status === 'invalid_token') {
        chrome.storage.local.remove(['extension_token', 'consent_given']);
        setTimeout(() => { hideFeedback(); showView('pairing'); }, 2000);
      } else {
        setTimeout(() => hideFeedback(), 3000);
      }
      
      if (result.status === 'synced') {
        updateSyncStatus(new Date().toISOString());
      }
    });
  });

  btnDisconnect.addEventListener('click', () => {
    btnDisconnect.disabled = true;
    chrome.runtime.sendMessage({ action: 'disconnect' }, () => {
      chrome.storage.local.remove(['extension_token', 'last_sync_at', 'consent_given']);
      btnDisconnect.disabled = false;
      showView('pairing');
    });
  });

  btnErrorRetry.addEventListener('click', () => {
    init();
  });

  init();
});
