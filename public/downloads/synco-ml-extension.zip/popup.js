document.addEventListener('DOMContentLoaded', () => {
  const views = {
    pairing:   document.getElementById('view-pairing'),
    connected: document.getElementById('view-connected'),
    mismatch:  document.getElementById('view-mismatch'),
    loading:   document.getElementById('view-loading'),
    error:     document.getElementById('view-error')
  };

  const btnPair               = document.getElementById('btn-pair');
  const btnSyncNow            = document.getElementById('btn-sync-now');
  const btnDisconnect         = document.getElementById('btn-disconnect');
  const btnMismatchDisconnect = document.getElementById('btn-mismatch-disconnect');
  const btnErrorRetry         = document.getElementById('btn-error-retry');
  const consentCheckbox       = document.getElementById('consent-checkbox');
  const pairingCodeInput      = document.getElementById('pairing-code-input');
  const pairingError          = document.getElementById('pairing-error');
  const syncFeedback          = document.getElementById('sync-feedback');
  const syncStatusText        = document.getElementById('sync-status-text');
  const accountBadge          = document.getElementById('account-badge');
  const accountBadgeValue     = document.getElementById('account-badge-value');
  const accountWarning        = document.getElementById('account-warning');

  function showView(name) {
    Object.values(views).forEach(v => v.classList.add('hidden'));
    views[name].classList.remove('hidden');
  }

  function updateSyncStatus(last_sync_at) {
    if (!last_sync_at) {
      syncStatusText.textContent = 'Última sync: nunca';
    } else {
      const d = new Date(last_sync_at);
      syncStatusText.textContent = 'Última sync: ' + d.toLocaleString('pt-BR');
    }
  }

  function showAccountBadge(label, prefix) {
    const display = label || (prefix ? prefix : null);
    if (display) {
      accountBadgeValue.textContent = display;
      accountBadge.classList.remove('hidden');
      accountWarning.classList.remove('hidden');
    } else {
      accountBadge.classList.add('hidden');
      accountWarning.classList.add('hidden');
    }
  }

  function showError(msg) {
    pairingError.textContent = msg;
    pairingError.classList.remove('hidden');
  }

  function hideError() {
    pairingError.classList.add('hidden');
  }

  function showFeedback(msg, isError) {
    syncFeedback.textContent = msg;
    syncFeedback.style.color = isError ? '#dc2626' : '';
    syncFeedback.classList.remove('hidden');
  }

  function hideFeedback() {
    syncFeedback.classList.add('hidden');
  }

  async function doDisconnect() {
    chrome.runtime.sendMessage({ action: 'disconnect' }, () => {
      chrome.storage.local.remove([
        'extension_token',
        'last_sync_at',
        'consent_given',
        'synco_user_id_prefix',
        'synco_account_label',
        'paired_at',
      ]);
      showView('pairing');
    });
  }

  function init() {
    chrome.storage.local.get([
      'extension_token',
      'last_sync_at',
      'synco_account_label',
      'synco_user_id_prefix',
    ], data => {
      if (data.extension_token) {
        showView('connected');
        updateSyncStatus(data.last_sync_at);
        showAccountBadge(data.synco_account_label, data.synco_user_id_prefix);
      } else {
        showView('pairing');
      }
    });
  }

  consentCheckbox.addEventListener('change', () => {
    btnPair.disabled = !consentCheckbox.checked;
  });

  btnPair.addEventListener('click', async () => {
    hideError();
    const code = pairingCodeInput.value.trim();
    if (!/^\d{6}$/.test(code)) {
      showError('Código inválido. Digite 6 dígitos.');
      return;
    }
    if (!consentCheckbox.checked) {
      showError('Aceite os termos para continuar.');
      return;
    }

    showView('loading');

    try {
      const response = await fetch(SYNCO_CONFIG.API_BASE_URL + SYNCO_CONFIG.ENDPOINTS.PAIRING_EXCHANGE, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pairing_code: code })
      });

      if (response.ok) {
        const data = await response.json();
        await chrome.storage.local.set({
          extension_token:      data.extension_token,
          consent_given:        true,
          synco_user_id_prefix: data.user_id_prefix  || null,
          synco_account_label:  data.account_label   || null,
          paired_at:            new Date().toISOString(),
        });

        showView('connected');
        showAccountBadge(data.account_label, data.user_id_prefix);

        chrome.runtime.sendMessage({ action: 'forceSync' }, result => {
          const syncedAt = result && result.status === 'synced' ? new Date().toISOString() : null;
          updateSyncStatus(syncedAt);
        });
      } else if (response.status === 401) {
        showError('Código inválido ou expirado.');
        showView('pairing');
      } else {
        showError('Não foi possível conectar. Tente novamente.');
        showView('pairing');
      }
    } catch (err) {
      showError('Não foi possível conectar. Tente novamente.');
      showView('pairing');
    }
  });

  btnSyncNow.addEventListener('click', () => {
    btnSyncNow.disabled = true;
    showFeedback('Sincronizando...', false);

    chrome.runtime.sendMessage({ action: 'forceSync' }, result => {
      btnSyncNow.disabled = false;

      if (result.status === 'token_user_mismatch') {
        hideFeedback();
        showView('mismatch');
        return;
      }

      const messages = {
        synced:           'Sincronizado com sucesso!',
        ml_not_logged_in: 'Faça login no Mercado Livre e tente novamente.',
        invalid_token:    'Sessão expirada. Reconecte a extensão.',
        sync_failed:      'Falha na sincronização. Tente novamente.',
        no_consent:       'Consentimento necessário.'
      };

      const isErr = result.status !== 'synced';
      const msg   = messages[result.status] || 'Resposta inesperada.';
      showFeedback(msg, isErr);

      if (result.status === 'invalid_token') {
        chrome.storage.local.remove([
          'extension_token',
          'consent_given',
          'synco_user_id_prefix',
          'synco_account_label',
          'paired_at',
        ]);
        setTimeout(() => { hideFeedback(); showView('pairing'); }, 2000);
      } else {
        setTimeout(() => hideFeedback(), 3000);
      }

      if (result.status === 'synced') {
        updateSyncStatus(new Date().toISOString());
      }
    });
  });

  btnDisconnect.addEventListener('click', () => {
    btnDisconnect.disabled = true;
    doDisconnect().finally(() => { btnDisconnect.disabled = false; });
  });

  btnMismatchDisconnect.addEventListener('click', () => {
    doDisconnect();
  });

  btnErrorRetry.addEventListener('click', () => {
    init();
  });

  init();
});
